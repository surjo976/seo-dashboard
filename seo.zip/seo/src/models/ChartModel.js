export default class ChartModel {
  constructor() {
    this.seoSummaryLines = [
      {
        "name": "SEO Health Score",
        "color": "#4FCE62", // Green
        "points": [
          { "x": -100, "y": 320, "value": 55 },
          { "x": 59, "y": 325, "value": 62 },
          { "x": 183, "y": 284, "value": 70 },
          { "x": 433, "y": 330, "value": 65 },
          { "x": 653, "y": 107, "value": 78 },
          { "x": 808, "y": 255, "value": 76 },
          { "x": 950, "y": 310, "value": 68 }
        ]
      },
      {
        "name": "Technical SEO",
        "color": "#3594ee", // Blue
        "points": [
          { "x": -100, "y": 242, "value": 68 },
          { "x": 6, "y": 229, "value": 72 },
          { "x": 195, "y": 329, "value": 60 },
          { "x": 367, "y": 187, "value": 82 },
          { "x": 536, "y": 315, "value": 64 },
          { "x": 721, "y": 48, "value": 91 },
          { "x": 950, "y": 248, "value": 78 }
        ]
      },
      {
        "name": "AI Visibility Score",
        "color": "#6645c7", // Purple
        "points": [
          { "x": -100, "y": 310, "value": 45 },
          { "x": 12, "y": 331, "value": 48 },
          { "x": 168, "y": 329, "value": 50 },
          { "x": 342, "y": 270, "value": 58 },
          { "x": 472, "y": 183, "value": 58 },
          { "x": 640, "y": 291, "value": 52 },
          { "x": 839, "y": 332, "value": 46 },
          { "x": 950, "y": 310, "value": 45 }
        ]
      },
      {
        "name": "Content Quality",
        "color": "#C27733", // Brown/Orange
        "points": [
          { "x": -100, "y": 280, "value": 50 },
          { "x": 55, "y": 273, "value": 56 },
          { "x": 274, "y": 223, "value": 64 },
          { "x": 506, "y": 117, "value": 71 },
          { "x": 687, "y": 240, "value": 60 },
          { "x": 843, "y": 270, "value": 55 },
          { "x": 950, "y": 280, "value": 54 }
        ]
      }
    ];

    this.pagesCrawledConfig = {
      size: 258,
      segments: [
        { startDeg: 0, endDeg: 360, color: "#3594ee", radius: 96, lineWidth: 54, type: "progress", progressDeg: 335 },
        { startDeg: 0, endDeg: 360, color: "#e0e0e0", radius: 88, lineWidth: 38, type: "background" }
      ]
    };

    this.issuesOverviewConfig = {
      size: 195,
      radius: 68,
      lineWidth: 26,
      shiftDist: 6,
      segments: [
        { start: -90, end: 0, color: "#3594EE", explode: true }, // Blue   90°
        { start: 0, end: 121, color: "#4FCE62", explode: false }, // Green 121°
        { start: 121, end: 211, color: "#FF9F4E", explode: false }, // Notice 90°
        { start: 211, end: 255, color: "#C27733", explode: false }, // Warnings 44°
        { start: 255, end: 270, color: "#FF6370", explode: false }  // Critical 15°
      ]
    };
  }
}
